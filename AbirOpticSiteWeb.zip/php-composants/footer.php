<section class="footer">
    <div class="footer-st">
        <div>
            <p>&copy; 2023 Abir optic - Tout droit réservés</p>
            <a href="mentions-legales.php">Mentions légales</a><br />
            <a href="cgv.php">CGV/CGU </a><br />
        </div>

        <h4>Suivez-nous</h4>
        <a href="https://www.facebook.com/abiroptic.page/?locale=fr_FR"> <img src="images/facebook.png" alt="facebook de abir optic" height="30px" width="30px">
        </a>

        <a href="https://www.instagram.com/abiroptic/"> <img src="images/instagram.png" alt="instagram de abir optic" height="30px" width="30px"> </a>

    </div>
</section>